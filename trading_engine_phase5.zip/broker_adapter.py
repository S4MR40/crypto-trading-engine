import asyncio, os
from typing import Dict, Any, Optional
import ccxt.async_support as ccxt

class BrokerAdapter:
    def __init__(self, exchange_id: str = "kraken", paper_trading: bool = True, api_key: Optional[str] = None, secret: Optional[str] = None):
        self.exchange_id = exchange_id
        self.paper_trading = paper_trading
        exchange_class = getattr(ccxt, exchange_id, None)
        if not exchange_class:
            raise ValueError(f"Unsupported exchange: {exchange_id}")
        self.exchange = exchange_class({
            "apiKey": api_key or os.getenv("EXCHANGE_API_KEY", ""),
            "secret": secret or os.getenv("EXCHANGE_SECRET", ""),
            "enableRateLimit": True
        })

    async def execute_trade(self, signal: Dict[str, Any], position_size_usd: float = 1000.0) -> Dict[str, Any]:
        symbol = signal["symbol"]
        direction = signal["direction"]
        entry_price = signal["entry_price"]
        quantity = position_size_usd / entry_price
        side = "buy" if direction == "LONG" else "sell"

        if self.paper_trading:
            return {
                "status": "EXECUTED_PAPER",
                "exchange": self.exchange_id,
                "symbol": symbol,
                "side": side,
                "amount": round(quantity, 6),
                "entry_price": entry_price,
                "position_size_usd": position_size_usd,
                "paper_order_id": f"paper_{symbol.replace("/", "_")}_{int(asyncio.get_event_loop().time())}"
            }

        try:
            order = await self.exchange.create_order(symbol=symbol, type="market", side=side, amount=quantity)
            return {"status": "EXECUTED_LIVE", "order_id": order.get("id"), "symbol": symbol, "side": side, "amount": quantity}
        except Exception as e:
            return {"status": "EXECUTION_FAILED", "symbol": symbol, "error": str(e)}

    async def close(self):
        await self.exchange.close()
